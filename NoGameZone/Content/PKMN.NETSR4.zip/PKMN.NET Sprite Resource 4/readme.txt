PKMN.NET SPRITE RESOURCE DOWNLOAD v4.0.0

This collection of sprites from the official Pok�mon RPG games has been compiled by Typhlosion for PKMN.NET, with coding help from Joeno. A lot of it actually. Thanks to Peter, Kay, Liam and The Doctor for help in organising these sprites.

These sprites do not belong to PKMN.NET and are � Nintendo. You are free to use these sprites where you wish and to distribute them without permission or credit. Although credit is always nice. So is money. Or if all else fails, chocolate. Actually, alcohol works as well. But only if you're above 18.

The initial design of the Sprite Resource on the site ensured a number of repetitions - I have tried to remove this as much as possible, to reduce the size of this download. Remembering there are thousands of sprites, there will probably be some mistakes somewhere. If you find any, please report them via the forums or by contacting me at seniorstaff@pkmn.net.

The DPPt sprites have been moved around a little this time. Well, I've attempted to. It'll be wrong somewhere, sods law. You can now find male sprites, genderless sprites and sprites without gender differences in the Male folders. Any sprites specifically different for females will be found... yes, in the female folders. Well done you.

A massive thanks must go to the lovely Kay here for doing a little bit of the work for the BW sprites.

Actually make that a LOT of the work.

... Okay okay, she did EVERYTHING. Kay, you're brilliant. :P

In addition, Peter did 3 of the 5 generations of trainer sprites for me. For that, he is also brilliant.

Sprite Resource v5 is when item sprites will be introducted. Oh and a further reshuffle of the structure. Any further requests should be made on the forums or by emailling me at seniorstaff@pkmn.net.

VERSION HISTORY

v4.0.0 Added trainer sprites for all 5 generations.
v3.0.1 Error fixes.
v3.0.0 Added HeartGold/SoulSilver sprites and Black/White sprites.
v2.0.1 Fixed Platinum sprites omissions as reported by Chaos Rush in the forums.
v2.0.0 Restructured sprites to remove some repetition. Included all sprites from Platinum, Mystery Dungeon, Mystery Dungeon 2 and Trozei.
v1.1.0 Included some sprites from Mystery Dungeon 2, Pinball, Pinball R/S and Platinum.
v1.0.0 Included all major sprites for all 4 generations of RPG.
